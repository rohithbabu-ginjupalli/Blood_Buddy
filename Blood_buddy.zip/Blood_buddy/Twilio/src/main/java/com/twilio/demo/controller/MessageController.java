package com.twilio.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.api.v2010.account.MessageCreator;
import com.twilio.type.PhoneNumber;
import com.twilio.Twilio;
import com.twilio.demo.model.Numbers;

@RestController
public class MessageController {

	@Value("${accountSID}")
    private String accountSID;
 
    @Value("${accountAuthToken}")
    private String accountAuthToken;
 
    @Value("${twilloSenderNumber}")
    private String twilloSenderNumber;
    
	@PostMapping("/messages")
	public String login(@RequestBody Numbers numbers) {
		  String text = numbers.getMessage();
		  Twilio.init(accountSID, accountAuthToken); 
		  PhoneNumber recieverPhoneNumber = new PhoneNumber("+19094029891"); 
		  PhoneNumber senderTwilloPhoneNumber = new PhoneNumber(twilloSenderNumber); 
		  MessageCreator creator = com.twilio.rest.api.v2010.account.Message. creator(recieverPhoneNumber,
		  senderTwilloPhoneNumber, text); 
			 Message create = creator.create(); 
		 
		return "login";
	}
	
	/*
	 * @RequestMapping("/message") public String loginn() {
	 * 
	 * 
	 * 
	 * return "login"; }
	 */
}
