package com.twilio.demo.model;

import java.util.List;

public class Numbers {

	private List<String> list;
	
	private String message;

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
