package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.DonorInfo;

@Repository
public interface DonorInfoRepository extends JpaRepository<DonorInfo,Integer>{

	
	@Query(value="SELECT d FROM donor_info d WHERE d.donor_latitude <= :lati_max and d.donor_latitude >= :lati_min"
			+ " and d.donor_longitude >= :long_min and d.donor_longitude <= :long_max",
			nativeQuery=true)
	List<DonorInfo> getDonorsByLocation(@Param(value = "lati_max") String lati_max,@Param(value = "lati_min") String lati_min,@Param(value = "long_min") String long_min,
			@Param(value = "long_max") String long_max);
}
