package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.TrackingInfo;

public interface TrackingInfoRepository extends JpaRepository<TrackingInfo,Integer> {

}
