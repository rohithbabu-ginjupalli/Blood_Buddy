package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name = "tracking_info")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@JsonView
public class TrackingInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "track_id")
	private int track_id;
	
	@Column(name = "alert_id")
	private int alertId;
	
	@Column(name = "donor_id")
	private int donorId;
	
	@Column(name = "hospital_id")
	private int hospitalId;

	@Column(name = "tracking_status")
	private boolean trackingStatus;

	
	public TrackingInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public TrackingInfo(int track_id, int alertId, int donorId, int hospitalId, boolean trackingStatus) {
		super();
		this.track_id = track_id;
		this.alertId = alertId;
		this.donorId = donorId;
		this.hospitalId = hospitalId;
		this.trackingStatus = trackingStatus;
	}



	public int getTrack_id() {
		return track_id;
	}

	public void setTrack_id(int track_id) {
		this.track_id = track_id;
	}

	public int getAlertId() {
		return alertId;
	}

	public void setAlertId(int alertId) {
		this.alertId = alertId;
	}

	public int getDonorId() {
		return donorId;
	}

	public void setDonorId(int donorId) {
		this.donorId = donorId;
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public boolean isTrackingStatus() {
		return trackingStatus;
	}

	public void setTrackingStatus(boolean trackingStatus) {
		this.trackingStatus = trackingStatus;
	}
	
	
}
