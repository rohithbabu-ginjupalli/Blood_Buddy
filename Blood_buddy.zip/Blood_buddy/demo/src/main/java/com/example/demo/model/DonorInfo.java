package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name = "donor_info")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@JsonView
public class DonorInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "donor_id")
	private int donor_id;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="dob")
	private String dob;
	
	@Column(name="blood_group")
	private String bloodGroup;
	
	@Column(name="phone")
	private String phone;
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	@Column(name="donation_count")
	private String donationCount;
	
	@Column(name="donor_latitude")
	private String donorLatitude;
	
	@Column(name="donor_longitude")
	private String donorLongitude;
	
	@Column(name="created_date")
	private String createdDate;
	
	@Column(name="updated_date")
	private String updatedDate;

	public DonorInfo(int donor_id, String firstName, String lastName, String dob, String bloodGroup, String phone,
			String email, String address, String city, String state, String donationCount, String donorLatitude,
			String donorLongitude, String createdDate, String updatedDate) {
		super();
		this.donor_id = donor_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.bloodGroup = bloodGroup;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.city = city;
		this.state = state;
		this.donationCount = donationCount;
		this.donorLatitude = donorLatitude;
		this.donorLongitude = donorLongitude;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
	}

	public DonorInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDonor_id() {
		return donor_id;
	}

	public void setDonor_id(int donor_id) {
		this.donor_id = donor_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDonationCount() {
		return donationCount;
	}

	public void setDonationCount(String donationCount) {
		this.donationCount = donationCount;
	}

	public String getDonorLatitude() {
		return donorLatitude;
	}

	public void setDonorLatitude(String donorLatitude) {
		this.donorLatitude = donorLatitude;
	}

	public String getDonorLongitude() {
		return donorLongitude;
	}

	public void setDonorLongitude(String donorLongitude) {
		this.donorLongitude = donorLongitude;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
