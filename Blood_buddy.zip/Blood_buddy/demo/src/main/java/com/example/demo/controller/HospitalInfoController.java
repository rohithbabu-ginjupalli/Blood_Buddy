package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.DonorInfo;
import com.example.demo.model.HospitalInfo;
import com.example.demo.service.HospitalInfoServiceImpl;

@Controller
public class HospitalInfoController {

	@Autowired
	HospitalInfoServiceImpl hospitalInfoServiceImpl;
	
	@RequestMapping("/savehospitalinfo")
	public String getDonorsList(@RequestParam("userName") String userName,@RequestParam("password") String password,
			@RequestParam("hospName") String hospName,@RequestParam("phone") String phone,@RequestParam("address") String address,
			@RequestParam("branch") String branch,@RequestParam("city") String city,
			@RequestParam("state") String state,HttpSession session) {
		
		HospitalInfo info = new HospitalInfo();
		info.setUserName(userName);
		info.setPassword(password);
		info.setHospitalName(hospName);
		info.setHospitalPhone(phone);
		info.setHospitalAddress(address);
		info.setHosiptalCity(city);
		info.setHospitalState(state);
		info.setHospitalBranch(branch);
		final String uri = "http://api.openweathermap.org/geo/1.0/direct?"
				+ "q="+city+"&limit=1&appid=88318634fb6812ef8697ea262e7a528b";

	    RestTemplate restTemplate = new RestTemplate();
	    String result = restTemplate.getForObject(uri, String.class);
	    System.out.println(result);
	    JSONArray json = new JSONArray(result);
	    JSONObject js = json.getJSONObject(0);
	    String latitude = String.valueOf(js.getDouble("lat"));
	    String longitude = String.valueOf(js.getDouble("lon"));
	    info.setHospitalLatitude(latitude);
	    info.setHospitalLongitude(longitude);
	    SimpleDateFormat formatter= new SimpleDateFormat("MM-dd-yyyy");
		Date date = new Date(System.currentTimeMillis());
		
		info.setCreatedDate(formatter.format(date));
		info.setUpdatedDate(formatter.format(date));
	    hospitalInfoServiceImpl.saveHospitalInfo(info);
		return "signup";
	}
}
