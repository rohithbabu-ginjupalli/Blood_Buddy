package com.example.demo.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.DonorInfo;
import com.example.demo.service.DonorInfoServiceImpl;

@RestController
public class DonorInfoRestController {

	@Autowired
	private DonorInfoServiceImpl donorinfoServiceImpl;
	
	@RequestMapping("/getdonorinfo")
	public List<DonorInfo> getDonorInfo(){
		return donorinfoServiceImpl.getDonors();
	}
	
}
