package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.HospitalInfo;
import com.example.demo.repo.HospitalInfoRepository;

@Service
public class HospitalInfoServiceImpl {

	@Autowired
	private HospitalInfoRepository hospitalInfoRepository;
	
 public HospitalInfo saveHospitalInfo(HospitalInfo hospitalInfo) {
	return hospitalInfoRepository.save(hospitalInfo); 
 }
 public HospitalInfo getHospitalInfoById(int id) {
	 return hospitalInfoRepository.getById(id);
 }
 public HospitalInfo getHospitalInfoByUserName(String userName) {
	 return hospitalInfoRepository.findHospitalInfoByUserName(userName);
 }
}
