package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name = "hospital_info")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@JsonView
public class HospitalInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hospital_id")
	private int hospital_id;
	
	@Column(name="hospital_name")
	private String hospitalName;
	
	@Column(name="user_name")
	private String userName;
	
	@Column(name="password")
	private String password;
	
	@Column(name="hospital_phone")
	private String hospitalPhone;
	
	@Column(name="created_date")
	private String createdDate;
	
	@Column(name="hospital_address")
	private String hospitalAddress;
	
	@Column(name="hospital_branch")
	private String hospitalBranch;
	
	@Column(name="hosiptal_city")
	private String hosiptalCity;
	
	@Column(name="hospital_state")
	private String hospitalState;
	
	@Column(name="hospital_latitude")
	private String hospitalLatitude;
	
	@Column(name="hospital_longitude")
	private String hospitalLongitude;
	
	@Column(name="updated_date")
	private String updatedDate;

	public int getHospital_id() {
		return hospital_id;
	}

	public void setHospital_id(int hospital_id) {
		this.hospital_id = hospital_id;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHospitalPhone() {
		return hospitalPhone;
	}

	public void setHospitalPhone(String hospitalPhone) {
		this.hospitalPhone = hospitalPhone;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getHospitalAddress() {
		return hospitalAddress;
	}

	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}

	public String getHospitalBranch() {
		return hospitalBranch;
	}

	public void setHospitalBranch(String hospitalBranch) {
		this.hospitalBranch = hospitalBranch;
	}

	public String getHosiptalCity() {
		return hosiptalCity;
	}

	public void setHosiptalCity(String hosiptalCity) {
		this.hosiptalCity = hosiptalCity;
	}

	public String getHospitalState() {
		return hospitalState;
	}

	public void setHospitalState(String hospitalState) {
		this.hospitalState = hospitalState;
	}

	public String getHospitalLatitude() {
		return hospitalLatitude;
	}

	public void setHospitalLatitude(String hospitalLatitude) {
		this.hospitalLatitude = hospitalLatitude;
	}

	public String getHospitalLongitude() {
		return hospitalLongitude;
	}

	public void setHospitalLongitude(String hospitalLongitude) {
		this.hospitalLongitude = hospitalLongitude;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
